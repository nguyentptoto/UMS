<?php
/**
 * Giao diện quản lý danh mục nhà máy.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$is_editing = ! empty( $editing_factory_location );
$page_url   = admin_url( 'admin.php?page=tvn-ums-factory-locations' );
$grid_rows  = array();

foreach ( $factory_locations as $factory_location ) {
	$edit_url = add_query_arg(
		array(
			'page'                     => 'tvn-ums-factory-locations',
			'edit_factory_location_id' => absint( $factory_location['factory_location_id'] ),
		),
		admin_url( 'admin.php' )
	);
	$delete_url = wp_nonce_url(
		add_query_arg(
			array(
				'action'              => 'ums_delete_factory_location',
				'factory_location_id' => absint( $factory_location['factory_location_id'] ),
			),
			admin_url( 'admin-post.php' )
		),
		'ums_delete_factory_location_' . absint( $factory_location['factory_location_id'] )
	);

	$grid_rows[] = array(
		'factory_location_code' => $factory_location['factory_location_code'],
		'factory_location_name' => $factory_location['factory_location_name'],
		'status'                => (int) $factory_location['is_active'] === 1 ? 'Đang sử dụng' : 'Ngừng sử dụng',
		'actions'               => '<a href="' . esc_url( $edit_url . '#ums-factory-location-form' ) . '">Sửa</a> | <a href="' . esc_url( $delete_url ) . '" class="ums-delete-link" data-confirm="Xóa nhà máy ' . esc_attr( $factory_location['factory_location_code'] ) . '? Chỉ nên xóa khi chưa có nhân sự thuộc nhà máy này.">Xóa</a>',
	);
}

$grid_columns = array(
	array( 'text' => 'Mã nhà máy', 'datafield' => 'factory_location_code', 'width' => '25%' ),
	array( 'text' => 'Tên nhà máy', 'datafield' => 'factory_location_name', 'width' => '35%' ),
	array( 'text' => 'Trạng thái', 'datafield' => 'status', 'width' => '20%' ),
	array( 'text' => 'Thao tác', 'datafield' => 'actions', 'width' => '20%', 'filterable' => false, 'sortable' => false, 'cellsrenderer' => 'html' ),
);
?>

<div class="wrap ums-admin-wrap">
	<h1 class="wp-heading-inline">UMS - Quản lý Nhà máy</h1>
	<hr class="wp-header-end">

	<?php if ( ! empty( $notice ) ) : ?>
		<div class="notice notice-<?php echo esc_attr( $notice['type'] ); ?> is-dismissible">
			<p><?php echo esc_html( $notice['message'] ); ?></p>
		</div>
	<?php endif; ?>

	<div class="ums-panel">
		<h2>Danh sách nhà máy</h2>
		<form method="get" class="ums-filter-bar">
			<input type="hidden" name="page" value="tvn-ums-factory-locations">
			<input type="search" name="s" value="<?php echo esc_attr( $filters['search'] ); ?>" placeholder="Tìm mã hoặc tên nhà máy">
			<select name="status">
				<option value="">Tất cả trạng thái</option>
				<option value="active" <?php selected( $filters['status'], 'active' ); ?>>Đang sử dụng</option>
				<option value="inactive" <?php selected( $filters['status'], 'inactive' ); ?>>Ngừng sử dụng</option>
			</select>
			<button type="submit" class="button">Lọc</button>
			<a href="<?php echo esc_url( $page_url ); ?>" class="button button-link">Xóa lọc</a>
		</form>

		<div id="ums-factory-location-grid" class="ums-jqx-grid" data-rows="<?php echo esc_attr( wp_json_encode( $grid_rows ) ); ?>" data-columns="<?php echo esc_attr( wp_json_encode( $grid_columns ) ); ?>"></div>
	</div>

	<div class="ums-panel" id="ums-factory-location-form">
		<h2><?php echo $is_editing ? 'Cập nhật nhà máy' : 'Thêm nhà máy'; ?></h2>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="ums-profile-form">
			<?php wp_nonce_field( 'ums_save_factory_location' ); ?>
			<input type="hidden" name="action" value="ums_save_factory_location">
			<input type="hidden" name="ums_factory_location[is_edit]" value="<?php echo $is_editing ? '1' : '0'; ?>">
			<input type="hidden" name="ums_factory_location[factory_location_id]" value="<?php echo esc_attr( $form_values['factory_location_id'] ); ?>">

			<div class="ums-form-grid">
				<label>
					<span>Mã nhà máy <b>*</b></span>
					<input type="text" name="ums_factory_location[factory_location_code]" value="<?php echo esc_attr( $form_values['factory_location_code'] ); ?>" required>
				</label>
				<label>
					<span>Tên nhà máy <b>*</b></span>
					<input type="text" name="ums_factory_location[factory_location_name]" value="<?php echo esc_attr( $form_values['factory_location_name'] ); ?>" required>
				</label>
			</div>

			<fieldset class="ums-checkboxes">
				<legend>Trạng thái</legend>
				<label><input type="checkbox" name="ums_factory_location[is_active]" value="1" <?php checked( (int) $form_values['is_active'], 1 ); ?>> Đang sử dụng</label>
			</fieldset>

			<p class="submit">
				<button type="submit" class="button button-primary"><?php echo $is_editing ? 'Cập nhật nhà máy' : 'Thêm nhà máy'; ?></button>
				<?php if ( $is_editing ) : ?>
					<a href="<?php echo esc_url( $page_url . '#ums-factory-location-form' ); ?>" class="button">Hủy sửa</a>
				<?php endif; ?>
			</p>
		</form>
	</div>
</div>
