(function ($) {
    'use strict';

    function initializeApprovalStepOrder() {
        var selector = 'input[name="ums_approval_flow[step_order]"]';
        var $inputs = $(selector);

        $inputs.attr({ min: 1, step: 1 });

        $inputs.on('input', function () {
            var value = $(this).val();

            if (value !== '' && parseInt(value, 10) < 1) {
                $(this).val(1);
            }
        });

        $inputs.on('blur change', function () {
            var value = parseInt($(this).val(), 10);

            if (!Number.isFinite(value) || value < 1) {
                $(this).val(1);
            }
        });
    }

	function initializeApprovalResolverFields() {
		var $resolver = $('#ums-approval-resolver-type');
		if (!$resolver.length) {
			return;
		}

		function refreshResolverFields() {
			var mode = $resolver.val() === 'position' ? 'position' : 'specific';
			$('[data-ums-resolver-section]').each(function () {
				$(this).prop('hidden', $(this).data('ums-resolver-section') !== mode);
			});
		}

		$resolver.on('change', refreshResolverFields);
		refreshResolverFields();
	}

	function initializeSearchableSelects() {
		if (typeof $.fn.select2 !== 'function') {
			return;
		}

		$('.ums-search-select').each(function () {
			var $select = $(this);
			if ($select.hasClass('select2-hidden-accessible')) {
				return;
			}

			$select.select2({
				width: '100%',
				placeholder: $select.attr('data-placeholder') || 'Tìm và chọn',
				allowClear: !$select.prop('multiple') && !$select.prop('required'),
				closeOnSelect: !$select.prop('multiple'),
				language: {
					noResults: function () { return 'Không tìm thấy dữ liệu'; },
					searching: function () { return 'Đang tìm...'; }
				}
			});
		});
	}

    function initializeOrganizationGrid() {
        $('.ums-jqx-remote-grid').each(function () {
            var $grid = $(this);
            var columns = $grid.data('columns') || [];
            var fields = $grid.data('fields') || [];
            var filters = $grid.data('filters') || {};

            if (typeof columns === 'string') {
                columns = JSON.parse(columns || '[]');
            }
            if (typeof fields === 'string') {
                fields = JSON.parse(fields || '[]');
            }
            if (typeof filters === 'string') {
                filters = JSON.parse(filters || '{}');
            }

            var source = {
                datatype: 'json',
                datafields: fields,
                id: 'source_id',
                url: $grid.attr('data-url'),
                type: 'POST',
                root: 'rows',
                cache: false,
                data: $.extend({}, filters, {
                    action: 'ums_get_organization_employees',
                    security: $grid.attr('data-nonce')
                }),
                beforeprocessing: function (data) {
                    source.totalrecords = parseInt(data.total, 10) || 0;
                },
                sort: function () {
                    $grid.jqxGrid('updatebounddata', 'sort');
                }
            };
            var dataAdapter = new $.jqx.dataAdapter(source);

            $grid.jqxGrid({
                width: '100%',
                autoheight: true,
                source: dataAdapter,
                columns: columns,
                theme: 'energyblue',
                pageable: true,
                virtualmode: true,
                rendergridrows: function (params) {
                    return params.data;
                },
                pagesize: 20,
                pagesizeoptions: ['10', '20', '50', '100'],
                sortable: true,
                filterable: false,
                columnsresize: true,
                altrows: true,
                enablebrowserselection: true,
                localization: {
                    emptydatastring: 'Không có dữ liệu',
                    loadtext: 'Đang tải...',
                    pagergotopagestring: 'Trang:',
                    pagershowrowsstring: 'Số dòng:',
                    pagerrangestring: ' / '
                }
            });
        });
    }

	function initializeDistributionEmail() {
		var $form = $('#ums-distribution-compose-form');
		var $table = $('#ums-email-schedule-table');
		if (!$form.length || !$table.length) {
			return;
		}

		var nextIndex = $table.find('tbody tr').length;
		function markPreviewStale() {
			var $sendButton = $('#ums-distribution-send-form button[type="submit"]');
			if ($sendButton.length) {
				$sendButton.prop('disabled', true);
				$('#ums-distribution-preview-stale').prop('hidden', false);
			}
		}

		$form.on('input change', 'input, textarea', markPreviewStale);
		$('#ums-email-add-slot').on('click', function () {
			if ($table.find('tbody tr').length >= 30) {
				return;
			}
			var index = nextIndex++;
			var $row = $('<tr/>');
			$('<td/>').append($('<input/>', {
				type: 'text', name: 'ums_distribution_email[schedule][' + index + '][time]',
				placeholder: '9:00 - 10:00'
			})).appendTo($row);
			$('<td/>').append($('<input/>', {
				type: 'text', name: 'ums_distribution_email[schedule][' + index + '][department]',
				placeholder: 'Multi, HP'
			})).appendTo($row);
			$('<td/>').append($('<button/>', {
				type: 'button', class: 'button-link ums-email-remove-slot',
				title: 'Xóa khung giờ', 'aria-label': 'Xóa khung giờ'
			}).append($('<span/>', { class: 'dashicons dashicons-no-alt', 'aria-hidden': 'true' }))).appendTo($row);
			$table.find('tbody').append($row);
			markPreviewStale();
			$row.find('input').first().trigger('focus');
		});
		$table.on('click', '.ums-email-remove-slot', function () {
			var $rows = $table.find('tbody tr');
			if ($rows.length === 1) {
				$rows.find('input').val('');
			} else {
				$(this).closest('tr').remove();
			}
			markPreviewStale();
		});
		$('#ums-distribution-send-form').on('submit', function () {
			if (!window.confirm('Gửi lịch cấp phát tới toàn bộ người nhận To và CC đang hiển thị?')) {
				return false;
			}
			$(this).find('button[type="submit"]').prop('disabled', true);
			return true;
		});
	}

    $(function () {
        initializeApprovalStepOrder();
		initializeApprovalResolverFields();
		initializeSearchableSelects();
        initializeOrganizationGrid();
		initializeDistributionEmail();

        $(document).on('click', '.ums-delete-link', function (event) {
            var message = $(this).data('confirm') || 'Bạn có chắc muốn xóa hồ sơ này?';

            if (!window.confirm(message)) {
                event.preventDefault();
            }
        });

        $(document).on('click', '.ums-sync-password-button', function (event) {
            event.preventDefault();

            var $button = $(this);
            var userIds = $button.data('user-ids') || [];
            var userId = parseInt($button.data('user-id'), 10) || 0;

            if (typeof userIds === 'string') {
                try {
                    userIds = JSON.parse(userIds || '[]');
                } catch (error) {
                    userIds = [];
                }
            }

            if (!Array.isArray(userIds) || userIds.length === 0) {
                userIds = userId ? [userId] : [];
            }

            if (!userIds.length || !window.umsAdmin) {
                window.alert('Không tìm thấy tài khoản WordPress cần đồng bộ.');
                return;
            }

            if (!window.confirm('Đồng bộ mật khẩu cho ' + userIds.length + ' tài khoản đang hiển thị? Nếu DB nguồn lỗi, hệ thống sẽ đặt mật khẩu mặc định.')) {
                return;
            }

            $button.prop('disabled', true).text('Đang đồng bộ...');

            $.post(window.umsAdmin.ajaxUrl, {
                action: 'ums_sync_user_password',
                security: window.umsAdmin.passwordSyncNonce,
                user_ids: userIds
            }).done(function (response) {
                var message = response && response.data && response.data.message
                    ? response.data.message
                    : 'Đã đồng bộ mật khẩu.';
                window.alert(message);
            }).fail(function (xhr) {
                var response = xhr.responseJSON || {};
                var message = response.data && response.data.message
                    ? response.data.message
                    : 'Không đồng bộ được mật khẩu.';
                window.alert(message);
            }).always(function () {
                $button.prop('disabled', false).text('Đồng bộ mật khẩu');
            });
        });

        var $prForm = $('#ums-pr-calculation-form');
        if ($prForm.length) {
            var $calculatePr = $('#ums-calculate-pr');
            var $exportPr = $('#ums-export-pr');
            var $prStatus = $('#ums-pr-status');
            var $prPanel = $('#ums-pr-result-panel');
            var $prMessages = $('#ums-pr-messages');
            var $prSummary = $('#ums-pr-summary');
            var $prGrid = $('#ums-pr-result-grid');
            var numberFormat = new Intl.NumberFormat('vi-VN');

            function markPrResultStale() {
                $exportPr.prop('disabled', true);
                if ($prPanel.is(':visible')) {
                    $prStatus.text('Dữ liệu đầu vào đã thay đổi. Hãy tính lại trước khi xuất.');
                }
            }

            function renderPrMessages(errors, warnings) {
                $prMessages.empty();
                if (errors && errors.length) {
                    $('<div class="notice notice-error inline"><p></p></div>')
                        .find('p').text(errors.join(' ')).end()
                        .appendTo($prMessages);
                }
                if (warnings && warnings.length) {
                    $('<div class="notice notice-warning inline"><p></p></div>')
                        .find('p').text(warnings.join(' ')).end()
                        .appendTo($prMessages);
                }
            }

            function renderPrGrid(rows) {
                var source = {
                    datatype: 'array',
                    localdata: rows,
                    datafields: [
                        {name: 'sap_code', type: 'string'},
                        {name: 'item_name', type: 'string'},
                        {name: 'size', type: 'string'},
                        {name: 'periodic_qty', type: 'number'},
                        {name: 'reserve_qty', type: 'number'},
                        {name: 'stock_qty', type: 'number'},
                        {name: 'final_pr_qty', type: 'number'},
                        {name: 'base_price', type: 'number'},
                        {name: 'estimated_amount', type: 'number'}
                    ]
                };
                var adapter = new $.jqx.dataAdapter(source);
                var options = {
                    width: '100%',
                    autoheight: true,
                    source: adapter,
                    theme: 'energyblue',
                    pageable: true,
                    pagesize: 20,
                    pagesizeoptions: ['10', '20', '50', '100'],
                    sortable: true,
                    filterable: true,
                    showfilterrow: true,
                    columnsresize: true,
                    altrows: true,
                    columns: [
                        {text: 'Mã SAP', datafield: 'sap_code', width: 115},
                        {text: 'Loại đồng phục', datafield: 'item_name', minwidth: 260},
                        {text: 'Size', datafield: 'size', width: 70, cellsalign: 'center'},
						{text: 'SL cấp phát', datafield: 'periodic_qty', width: 100, cellsalign: 'right'},
                        {text: 'SL dự phòng', datafield: 'reserve_qty', width: 105, cellsalign: 'right'},
                        {text: 'Tồn kho', datafield: 'stock_qty', width: 90, cellsalign: 'right'},
                        {text: 'SL PR', datafield: 'final_pr_qty', width: 90, cellsalign: 'right'},
                        {text: 'Đơn giá', datafield: 'base_price', width: 120, cellsalign: 'right', cellsformat: 'n0'},
                        {text: 'Thành tiền dự kiến', datafield: 'estimated_amount', width: 155, cellsalign: 'right', cellsformat: 'n0'}
                    ],
                    localization: {
                        emptydatastring: 'Không có sản phẩm cần tính',
                        loadtext: 'Đang tải...',
                        pagergotopagestring: 'Trang:',
                        pagershowrowsstring: 'Số dòng:',
                        pagerrangestring: ' / '
                    }
                };

                if ($prGrid.hasClass('jqx-widget')) {
                    $prGrid.jqxGrid(options);
                    $prGrid.jqxGrid('updatebounddata');
                } else {
                    $prGrid.jqxGrid(options);
                }
            }

            $prForm.on('change input', 'input, select', markPrResultStale);

            $calculatePr.on('click', function () {
                var form = $prForm.get(0);
                if (!form.reportValidity()) {
                    return;
                }

                var payload = new FormData(form);
                payload.set('action', 'ums_calculate_pr');
                payload.set('security', $prForm.find('[name="pr_security"]').val());
                $calculatePr.prop('disabled', true).text('Đang tính...');
                $exportPr.prop('disabled', true);
                $prStatus.text('Đang đọc file và tổng hợp dữ liệu...');
                $prMessages.empty();

                $.ajax({
                    url: window.umsAdmin.ajaxUrl,
                    method: 'POST',
                    data: payload,
                    processData: false,
                    contentType: false
                }).done(function (response) {
                    if (!response || !response.success) {
                        throw new Error('Không nhận được kết quả tính PR hợp lệ.');
                    }

                    var data = response.data;
                    var summary = data.summary || {};
                    renderPrGrid(data.rows || []);
                    renderPrMessages([], data.warnings || []);
					$prSummary.text(
						'Kho ' + (data.factory_name || data.factory_code || '') +
						' | Cấp phát: ' + numberFormat.format(summary.periodic_qty || 0) +
                        ' | Dự phòng: ' + numberFormat.format(summary.reserve_qty || 0) +
                        ' | Tồn kho: ' + numberFormat.format(summary.stock_qty || 0) +
                        ' | Số lượng PR: ' + numberFormat.format(summary.final_pr_qty || 0) +
                        ' | Giá trị dự kiến: ' + numberFormat.format(summary.estimated_amount || 0) + ' VND'
                    );
                    $prPanel.prop('hidden', false).show();
                    $exportPr.prop('disabled', !data.can_export);
                    $prStatus.text('Đã tính xong ' + numberFormat.format(summary.row_count || 0) + ' dòng.');
                }).fail(function (xhr) {
                    var response = xhr.responseJSON || {};
                    var data = response.data || {};
                    var errors = data.errors || [];
                    if (!errors.length && data.message) {
                        errors.push(data.message);
                    }
                    if (!errors.length) {
                        errors.push('Không thể tính số lượng PR.');
                    }
                    renderPrMessages(errors, []);
                    $prPanel.prop('hidden', false).show();
                    $prStatus.text('Tính PR thất bại.');
                }).always(function () {
                    $calculatePr.prop('disabled', false).text('Tính số lượng PR');
                });
            });
        }

        $('.ums-jqx-grid').each(function () {
            var $grid = $(this);
            var rows = $grid.data('rows') || [];
            var columns = $grid.data('columns') || [];
            var groups = $grid.data('groups') || [];

            if (typeof rows === 'string') {
                rows = JSON.parse(rows || '[]');
            }

            if (typeof columns === 'string') {
                columns = JSON.parse(columns || '[]');
            }

            if (typeof groups === 'string') {
                groups = JSON.parse(groups || '[]');
            }

            var source = {
                datatype: 'array',
                localdata: rows
            };
            var dataAdapter = new $.jqx.dataAdapter(source);

            columns = columns.map(function (column) {
                if (column.cellsrenderer === 'html') {
                    column.cellsrenderer = function (row, datafield, value) {
                        return '<div class="ums-jqx-cell-html">' + (value || '') + '</div>';
                    };
                }

                return column;
            });

            $grid.jqxGrid({
                width: '100%',
                autoheight: true,
                source: dataAdapter,
                columns: columns,
                theme: 'energyblue',
                pageable: true,
                pagesize: 20,
                pagesizeoptions: ['10', '20', '50', '100'],
                sortable: true,
                filterable: true,
                showfilterrow: true,
                columnsresize: true,
                altrows: true,
                groupable: groups.length > 0,
                groups: groups,
                enablebrowserselection: true,
                localization: {
                    emptydatastring: 'Không có dữ liệu',
                    filterstringcomparisonoperators: ['rỗng', 'không rỗng', 'chứa', 'chứa - phân biệt hoa thường', 'không chứa', 'không chứa - phân biệt hoa thường', 'bắt đầu bằng', 'bắt đầu bằng - phân biệt hoa thường', 'kết thúc bằng', 'kết thúc bằng - phân biệt hoa thường', 'bằng', 'bằng - phân biệt hoa thường', 'null', 'không null'],
                    filterselectstring: 'Chọn bộ lọc',
                    loadtext: 'Đang tải...',
                    pagergotopagestring: 'Trang:',
                    pagershowrowsstring: 'Số dòng:',
                    pagerrangestring: ' / '
                }
            });
        });
    });
})(jQuery);
