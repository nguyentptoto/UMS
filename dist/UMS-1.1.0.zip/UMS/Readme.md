# UMS - Uniform Management System

UMS là plugin WordPress quản lý hồ sơ nhân sự, phòng ban, chức danh, nhà máy, hợp đồng, danh mục sản phẩm đồng phục, tổng kho, định mức cấp phát hằng năm, phiếu yêu cầu cấp phát và luồng duyệt động theo phòng ban.

## Google Sheets Connector (UMS 1.1.0)

Các kết nối Google Sheet được tách thành plugin **UMS Google Sheets Connector**.
Cài plugin này vào `wp-content/plugins/ums-google-sheets-connector/`, ngang hàng
với `UMS/`, rồi kích hoạt trong WordPress. Link Sheet, token và API cũ được giữ
nguyên. Tắt Connector không xóa dữ liệu đã đồng bộ; bảng nhân sự, định mức, kho,
phiếu yêu cầu và import Excel vẫn thuộc UMS.

Mã nguồn phát triển của plugin mới nằm tại `packages/ums-google-sheets-connector/`.
Hướng dẫn nâng cấp, kiểm thử và quay lại bản cũ nằm trong README của thư mục đó.
Chạy `php tools/build-plugin-packages.php` để tạo hai ZIP riêng trong `dist/`.
Gói UMS không chứa source Connector, công cụ phát triển hoặc script có cấu hình
token tại máy. Không phát hành nguyên repository như một gói plugin.

## Nguyên Tắc Database

Toàn bộ cấu trúc bảng nằm trong `ums.sql`.

Plugin không tự tạo bảng, không tự migrate bảng, không chạy `CREATE TABLE`, `ALTER TABLE` hoặc `dbDelta`. Trước khi dùng plugin, hãy import thủ công `ums.sql` vào database WordPress.

File `ums.sql` hiện dùng prefix mặc định `wp_`. Nếu site dùng prefix khác, cần đổi prefix trong file SQL trước khi import.

Các bảng nghiệp vụ chính:

- `wp_uniform_departments`
- `wp_uniform_positions`
- `wp_uniform_factory_locations`
- `wp_uniform_contract_types`
- `wp_uniform_department_approval_flows`
- `wp_uniform_user_profiles`
- `wp_uniform_product_categories`
- `wp_uniform_inventory`
- `wp_uniform_inventory_import_batches`
- `wp_uniform_sap_import_batches`
- `wp_uniform_sap_materials`
- `wp_uniform_annual_allowance_rules`
- `wp_uniform_inventory_movements`
- `wp_uniform_requests`
- `wp_uniform_request_details`
- `wp_uniform_approval_logs`
- `wp_uniform_returns`
- `wp_uniform_organization_employees`

## Chức Năng Admin

- Quản lý Hồ sơ Nhân sự
- Quản lý Phòng ban
- Quản lý Chức danh
- Quản lý Nhà máy
- Quản lý Hợp đồng
- Quản lý Luồng duyệt phòng ban
- Quản lý Danh mục sản phẩm cha/con
- Quản lý Sản phẩm & Tổng kho
- Quản lý và import master Mã SAP đồng phục
- Xuất kho chủ động từ Admin
- Xem lịch sử nhập/xuất/điều chỉnh kho chi tiết
- Quản lý Định mức cấp phát hàng năm
- Quản lý và đồng bộ Sơ đồ tổ chức TVN
- Đồng bộ mật khẩu từ DB ngoài vào `wp_users.user_pass`

Hồ sơ nhân sự liên kết với tài khoản WordPress qua `wp_uniform_user_profiles.user_id`. Khi tạo hồ sơ, hệ thống tạo tài khoản WordPress tương ứng, `user_login` mặc định là mã nhân viên và mật khẩu mặc định là `12345678`.

Trang `Quản lý Phòng ban` có trường `department_group` để nhiều phòng ban cùng thuộc một nhóm. Danh sách hỗ trợ lọc theo nhóm và form gợi ý các nhóm đã có.

Import CSV UTF-8 sử dụng các cột `department_code`, `department_name`, `department_group`, `is_active`. Import upsert theo mã phòng ban: mã mới được tạo, mã đã tồn tại được cập nhật. File CSV cũ không có `department_group` vẫn được chấp nhận và giữ nguyên nhóm của phòng ban hiện tại. Khi tên phòng ban thay đổi, hồ sơ nhân sự liên quan được đồng bộ sang tên mới trong cùng transaction. Giao diện có nút tải CSV mẫu.

Với database đã cài UMS trước thay đổi này, chạy thủ công:

```sql
ALTER TABLE `wp_uniform_departments`
    ADD COLUMN `department_group` VARCHAR(150) NOT NULL DEFAULT '' AFTER `department_name`,
    ADD KEY `idx_department_group` (`department_group`);
```

## Master Mã SAP Đồng Phục

Admin quản lý tại menu `Mã SAP đồng phục`. Đây là dữ liệu đầu vào cho module `Tính số lượng PR`, dùng để liên kết mã SAP với từng sản phẩm và size trong kho.

Nguồn import là workbook GA `GA - Xây dựng phần mềm 100% 11đồng phục.xlsx`. Importer chỉ đọc sheet `Mã đồng phục` (chấp nhận tên sheet có khoảng trắng ở đầu) và bốn cột:

- `Mã đồng phục`: mã SAP dạng số, được lưu dưới dạng chuỗi để không làm thay đổi mã nguồn.
- `Loại`: tên loại/size chi tiết và là khóa nghiệp vụ ổn định của dòng import.
- `Loại đồng phục lên PR`: nhóm sản phẩm dùng cho bước tổng hợp PR sau này.
- `Size`: kích cỡ đồng phục; được phép trống nếu dòng nguồn không có size.

Quy trình gồm `Chọn file` -> `Đọc và xem trước` -> ánh xạ `Loại đồng phục lên PR` với Tên sản phẩm UMS -> kiểm tra lỗi/cảnh báo -> `Xác nhận import master mã SAP`. Khi tên hai bên giống nhau, giao diện tự chọn sản phẩm tương ứng. Hệ thống liên kết từng dòng GA theo `Sản phẩm + Size` và lưu khóa `inventory_item_id`; `2XL/XXL`, `3XL/XXXL` và size trống/`0` được nhận là tương đương. Size chưa có được tạo trong kho với tồn `0` và đơn giá chung của sản phẩm. Chỉ dữ liệu kho trùng hoặc sản phẩm đang có nhiều đơn giá chưa chuẩn hóa mới dừng import.

Dữ liệu được ghi theo batch trong transaction. File đã import thành công được nhận diện bằng SHA-256 để ngăn nhập trùng; dòng còn trong file được upsert, còn dòng không xuất hiện trong lần import mới nhất được chuyển sang trạng thái ngừng sử dụng.

Mã SAP xuất hiện ở nhiều loại/size không bị gộp hoặc tự sửa vì đây có thể là dữ liệu nghiệp vụ có chủ đích. Hệ thống giữ nguyên từng dòng, đánh dấu `duplicate_sap` và hiển thị cảnh báo để Admin kiểm tra. Hai bảng liên quan là `wp_uniform_sap_materials` và `wp_uniform_sap_import_batches`, được khai báo đầy đủ trong `ums.sql`.

## Định Mức Cấp Phát Hàng Năm

Admin quản lý tại menu `Định mức năm`.

Bảng dữ liệu: `wp_uniform_annual_allowance_rules`.

Một rule định mức gồm:

- `apply_type`: kiểu áp dụng, gồm `category` hoặc `item`.
- `category_id`: danh mục áp dụng. Nếu chọn danh mục, tất cả sản phẩm thuộc danh mục đó sẽ theo rule.
- `item_id`: sản phẩm cố định áp dụng.
- `target_type`: đối tượng áp dụng, gồm `all` hoặc `position`.
- `position_id`: chức vụ áp dụng khi `target_type = position`.
- `frequency_count`: số lần được cấp.
- `frequency_years`: số năm trong chu kỳ.
- `monthly_quantities`: JSON lưu số lượng cấp phát theo từng tháng.
- `is_active`: trạng thái áp dụng.

Ví dụ:

- Áo khoác áp dụng cho toàn bộ nhân sự.
- Tần suất `1 lần / 2 năm`.
- Tháng 4: `0`, tháng 9: `1`.

Khi user tạo hoặc sửa phiếu, hệ thống kiểm tra định mức trước khi lưu:

- Sản phẩm phải có rule định mức đang áp dụng.
- Rule có thể đến từ sản phẩm cố định hoặc danh mục cha/con.
- Rule phải phù hợp với chức vụ của CNV nhận đồng phục nếu rule áp dụng theo chức vụ.
- Tháng hiện tại phải có số lượng được phép cấp lớn hơn `0`.
- Tổng số lượng đã dùng trong tháng cộng với số lượng đang yêu cầu không được vượt định mức tháng.
- Số lần đã tạo phiếu trong chu kỳ không được vượt `frequency_count / frequency_years`.
- Phiếu bị `rejected` không tính vào định mức đã dùng.
- Khi sửa phiếu, hệ thống loại trừ chính phiếu đang sửa để tránh tính trùng.

### Xuất định mức theo từng CNV

Trang `Định mức năm` có khu vực `Xuất định mức theo từng CNV`. Phạm vi báo cáo chỉ lấy nhân sự có Cost center bắt đầu bằng `1300`, `4400` hoặc `4900`, không quét toàn bộ nhân sự trong Sơ đồ tổ chức. Admin chọn năm, kỳ Tháng 4/Tháng 9, một đầu Cost center cụ thể hoặc cả ba, sau đó có thể lọc tiếp theo mã nhân viên, phòng, nhóm, cost center chi tiết hoặc vị trí. Danh sách nhân sự được đọc trực tiếp từ Sơ đồ tổ chức TVN; hệ thống không dùng công thức `VLOOKUP` hoặc liên kết tới workbook nhân sự bên ngoài.

Tác vụ xuất đọc rule bằng truy vấn tối giản, chỉ tra tài khoản WordPress thuộc phạm vi CNV đã lọc, chỉ tải lịch sử của sản phẩm có rule và chia truy vấn lịch sử thành các batch nhỏ. Với database đã tồn tại trước bản tối ưu này, chạy một lần các index phục vụ báo cáo:

```sql
ALTER TABLE `wp_uniform_requests`
    ADD KEY `idx_allowance_request_history` (`target_user_id`, `created_at`, `current_status`);

ALTER TABLE `wp_uniform_inventory_movements`
    ADD KEY `idx_allowance_employee_history` (`target_employee_no`, `movement_type`, `created_at`),
    ADD KEY `idx_allowance_user_history` (`target_user_id`, `movement_type`, `created_at`);
```

Hai chế độ số lượng gồm:

- `Còn được nhận`: lấy định mức của kỳ rồi trừ phiếu chưa bị từ chối và lịch sử xuất kho chủ động trong chu kỳ.
- `Định mức gốc`: xuất nguyên số lượng của rule, không trừ lịch sử.

Rule được so khớp theo đúng thứ tự ưu tiên đang dùng khi tạo phiếu và xuất kho: phòng, nhóm, cost center, vị trí, ngày vào Công ty và scope CNV mới. Một rule sản phẩm chỉ được tính một lần dù sản phẩm có nhiều size. Form xuất chạy thẳng một lần và tải sheet `Total`, không tính trước hoặc dựng bảng xem trước. File gồm các cột `Mã nhân viên`, `Họ và tên`, `Phòng`, `Cost center`, `Mũ & Giày định mức`, `SL quần`, `SL áo phông`, `SL áo khoác` và `SL áo phao`.

File `.xlsx` được tạo mới hoàn toàn với dữ liệu tĩnh, bộ lọc và dòng tiêu đề cố định. Mỗi lần bấm xuất chỉ thực hiện một lượt tính và chứa đầy đủ nhân sự thỏa điều kiện.

### Import định mức từ Excel

Trang `Định mức năm` hỗ trợ import trực tiếp file `.xlsx` theo template quản lý đồng phục. Khi cài mới, import toàn bộ file `ums.sql`; bảng định mức linh hoạt và bảng `wp_uniform_allowance_import_batches` đã có sẵn trong cấu trúc hoàn chỉnh.

Form thêm/sửa thủ công bám đúng ma trận của hai sheet: Bộ phận, Nhóm, Code center, Vị trí, Sản phẩm, số lượng Tháng 4, số lượng Tháng 9, Lưu ý và Trạng thái. Khóa rule được sinh chung với dữ liệu import để tầng kiểm tra định mức xử lý thống nhất.

Danh sách định mức được trình bày bằng hai jqxGrid độc lập cho Tháng 4 và Tháng 9. Hai bảng giữ cùng các cột tổ chức và 26 cột sản phẩm E:AD, nhưng mỗi ô chỉ hiển thị số lượng của tháng tương ứng.

Chức năng xuất kho chủ động lấy người nhận trực tiếp từ Sơ đồ tổ chức TVN bằng mã nhân viên. Lịch sử kho lưu thêm `target_employee_no`, do đó Admin có thể xuất cho CNV không có tài khoản WordPress mà vẫn kiểm tra định mức, ngày vào và truy vết đúng người nhận.

Importer đọc hai sheet định mức thường và các ma trận dành cho CNV mới. Hai sheet định mức thường giữ cố định 26 cột sản phẩm từ `E` đến `AD`, trong đó cột `F` là `Áo phông dài tay`:

- `Phát T4`: định mức định kỳ tháng 4.
- `Phát T9`: định mức định kỳ tháng 9.

Các sheet CNV mới được đọc theo tiêu đề sản phẩm thực tế của từng sheet:

- `New commer`: bộ cấp ban đầu theo ngày nhận việc.
- `Phát T9 - CNV mới`: ma trận bổ sung tháng 9 tổng quát.
- Bốn sheet `ĐM ... T9 CNVM`: ma trận chi tiết theo cost center cho các khoảng `01/01-31/03`, `01/04-31/07`, `01/08-31/08` và `01/09-31/12`.
- `ĐM Giày T4N+1 CNVM vào 1.3N-31.`: cấp đúng một đôi giày vào tháng 4 năm N+1 cho CNV vào từ `01/03/N-31/08/N`.
- `ĐM Giày T9N+1 CNVM vào 1.9N-29.`: cấp đúng một đôi giày vào tháng 9 năm N+1 cho CNV vào từ `01/09/N-29/02/N+1`.

Tên sản phẩm trong Excel được giữ độc lập. Ví dụ `Áo phông xám`, `Áo phông cộc tay`, `Quần xám` và `Quần CN` là bốn sản phẩm khác nhau, không tự động gộp tên. Admin ánh xạ từng tên nguồn với đúng sản phẩm UMS tại bước xem trước.

Điều kiện áp dụng được lấy từ Sơ đồ tổ chức TVN theo `Mã nhân viên`: phòng, nhóm, cost center, vị trí và ngày vào công ty. Đối với các rule CNV mới, bao gồm hai scope giày N+1, hệ thống dùng cột `date_joined` của Sơ đồ tổ chức để xác định đúng khoảng ngày nhận việc và năm cấp; ngày trong usermeta/hồ sơ cũ chỉ được dùng dự phòng khi dữ liệu tổ chức chưa có. Tên sản phẩm trong Excel được ánh xạ với sản phẩm UMS trước khi xác nhận import; một mapping áp dụng cho toàn bộ size của sản phẩm đó.

Quy trình import gồm hai bước:

1. Chọn Excel và bấm `Đọc và xem trước`.
2. Kiểm tra thống kê, ánh xạ toàn bộ sản phẩm rồi bấm `Xác nhận import`.

Có thể import một sheet hoặc nhiều sheet trong mỗi lần tải file. Importer chỉ xử lý sheet đang hiển thị và bỏ qua sheet có trạng thái `hidden` hoặc `veryHidden`, vì vậy dữ liệu ẩn trong template không phát sinh thêm sản phẩm cần ánh xạ. Khi chỉ import `Phát T4`, hệ thống chỉ cập nhật tháng 4 và giữ nguyên dữ liệu tháng 9; quy tắc tương tự áp dụng cho các sheet dùng chung scope. Các sheet có scope độc lập như `New commer`, `Phát T9 - CNV mới`, giày T4 N+1 và giày T9 N+1 được thay thế riêng, không yêu cầu các sheet còn lại phải có mặt trong cùng file.

Import chạy theo batch trong transaction và cập nhật các rule trùng khóa. Scope độc lập hoặc bộ sheet đầy đủ sẽ vô hiệu hóa rule import cũ không còn trong dữ liệu mới; khi chỉ tải một sheet thuộc scope dùng chung, hệ thống giữ các rule còn lại để tránh làm mất dữ liệu của sheet chưa tải. Các rule nhập thủ công không bị xóa.

Thứ tự ưu tiên khi kiểm tra cấp phát:

1. `special_work_april` và `special_work_september`: định mức công việc đặc thù của kỳ tương ứng.
2. `newcomer_shoe_april` và `newcomer_shoe_september`: giày T4/T9 N+1 theo đúng sản phẩm được chỉ định.
3. `newcomer_september_override`: cấp bù tháng 9 theo cost center chi tiết.
4. `newcomer_september`: cấp bù tháng 9 tổng quát cho CNV vào trong năm.
5. `newcomer`: cấp ban đầu cho CNV mới.
6. `annual`: định mức định kỳ tháng 4/tháng 9.
7. Rule thủ công cũ khi nhân viên không thuộc ma trận Excel.

Ô chọn `Kỳ cấp` vẫn chỉ gồm T4 và T9. Đây là mốc thời gian đối chiếu, không phải bộ lọc loại định mức: trong kỳ đã chọn, hệ thống xét toàn bộ rule phù hợp với từng CNV (định kỳ, CNV mới, giày N+1 và công việc đặc thù), sau đó dùng ma trận có ưu tiên cao nhất cho từng sản phẩm để không cộng chồng các định mức thay thế nhau.

Chức năng `Tính số lượng cấp phát` đọc file đăng ký nhưng không xuất hoặc trừ tồn kho. Số lượng còn lại là giới hạn cấp tối đa: đăng ký ít hơn hoặc bằng giới hạn thì tính theo số đăng ký, đăng ký nhiều hơn thì tự giảm xuống đúng số lượng còn lại và ghi cảnh báo. Sản phẩm không thuộc định mức, size không hợp lệ hoặc CNV không có trong Sơ đồ tổ chức TVN bị loại khỏi kết quả nhưng không làm mất các dòng hợp lệ khác. Kết quả được chốt thành một snapshot theo `Năm + T4/T9`; snapshot mới thay thế snapshot đang hoạt động cùng kỳ và là nguồn nhu cầu cấp phát cho PR.

Sau khi chốt, hệ thống chuyển tới trang `Tính số lượng PR`. Khu vực `SL cấp phát đã chốt` hiển thị file nguồn, kỳ cấp, người chốt, tổng đăng ký, tổng cấp phát và bảng tổng hợp theo `Loại đồng phục lên PR + Size`. Có thể chuyển giữa các snapshot đang hoạt động của từng năm/kỳ; form tính PR tự chọn năm và kỳ của snapshot đang xem.

Marker của hai ma trận giày được gắn theo từng sản phẩm UMS sau bước ánh xạ. Vì vậy loại giày có số lượng `0` không rơi xuống định mức khác, đồng thời scope giày không che định mức áo, quần hoặc mũ trong cùng kỳ cấp phát.

Một ô số lượng `0` trong ma trận có nghĩa là không được cấp sản phẩm ở kỳ tương ứng. Mỗi dòng điều kiện được lưu thêm một marker ma trận, kể cả khi toàn bộ sản phẩm đều bằng `0`. Riêng CNV vào `01/09-31/12`, scope cấp bù T9 không được kích hoạt để nhân viên vẫn nhận đúng bộ cấp ban đầu `New commer`; rule cấp ban đầu đồng thời ngăn hệ thống rơi xuống định mức thường của tháng 9.

Chu kỳ năm được xác định theo ngày vào từ Sơ đồ tổ chức TVN. CNV vào từ tháng 9 đến tháng 12 năm A nhận bộ ban đầu theo khoảng `01/09-31/03`, không nhận bù kỳ tháng 9 năm A. Các sản phẩm thông thường tiếp tục được xét theo định mức T4/T9; riêng giày áp dụng chu kỳ N+1: nhóm vào `01/03/N-31/08/N` nhận giày tháng 4/N+1, còn nhóm vào `01/09/N-29/02/N+1` nhận giày tháng 9/N+1.

Import chỉ vô hiệu hóa dữ liệu cũ thuộc các scope có mặt trong file vừa import. Vì vậy import riêng workbook CNV mới không làm mất định mức thường `Phát T4/Phát T9` đã có.

## User Portal

Tạo một page WordPress và chèn shortcode:

```text
[ums_user_portal]
```

Portal dùng layout riêng của plugin, vẫn gọi các hook chuẩn `wp_head()`, `wp_body_open()` và `wp_footer()`.

Các trang portal hiện có:

- Tổng quan
- Tạo yêu cầu
- Phiếu của tôi
- Chi tiết phiếu
- Luồng duyệt
- Hồ sơ của tôi

Module `Tạo yêu cầu` hiển thị cho mọi tài khoản UMS đang hoạt động và có hồ sơ hợp lệ. Quyền tạo phiếu độc lập với chuỗi phê duyệt.

Khi gửi hoặc sửa phiếu, plugin không tin giá, số lượng hay thông tin nhân sự từ HTML. Hệ thống đọc lại sản phẩm và tồn kho, gộp các dòng trùng, lấy Phòng/Nhóm/Cost center/Vị trí/Ngày vào từ Sơ đồ tổ chức TVN, chọn rule định mức phù hợp rồi kiểm tra tháng cấp, số lượng bắt buộc của CNV mới, số lượng đã dùng và tần suất trước khi lưu phiếu. Rule cấp ban đầu cho CNV mới vẫn hoạt động trong engine dù không hiển thị thành một bảng riêng trên trang quản trị định mức.

Admin có quyền vào portal và xem toàn bộ phiếu ở góc nhìn quản trị.

## Luồng Tạo Yêu Cầu

Khi user hợp lệ bấm `Gửi duyệt`:

1. Hệ thống kiểm tra tài khoản người tạo đang hoạt động.
2. Hệ thống kiểm tra định mức cấp phát hàng năm theo từng dòng đồng phục.
3. Phiếu được lưu vào `wp_uniform_requests`.
4. Trạng thái ban đầu chuyển tới bước phê duyệt đầu tiên, ví dụ `pending_step_1`.
5. Chi tiết đồng phục được lưu vào `wp_uniform_request_details`.
6. Giá được tính lại từ dữ liệu kho: `base_price * quantity`.
7. Hệ thống tạo log `submitted` trong `wp_uniform_approval_logs` tại `step_order = 0`, tách biệt khỏi các bước duyệt.
8. Hệ thống ghi dòng `request_out` vào `wp_uniform_inventory_movements` để Admin nhìn thấy yêu cầu xuất kho theo từng vật tư.
9. Hệ thống gửi email cho người duyệt ở bước 1.

Luồng duyệt là chuỗi động theo bảng `wp_uniform_department_approval_flows`, không cố định 4 cấp.

Người tạo có thể sửa hoặc xóa phiếu khi bước duyệt đầu tiên chưa được duyệt. Phiếu bị từ chối có thể sửa hoặc xóa để gửi lại.

## Duyệt Phiếu Và Xuất Kho

Khi phiếu đi qua từng bước duyệt:

- Người duyệt tại bước hiện tại có thể duyệt hoặc từ chối.
- Khi duyệt, phiếu chuyển sang bước kế tiếp trong chuỗi luồng động.
- Khi từ chối, người duyệt phải nhập lý do từ chối.
- Khi phiếu được duyệt hoàn toàn, hệ thống ghi nhận xuất kho và trừ tồn kho tương ứng.
- Nếu tồn kho không đủ tại thời điểm hoàn tất duyệt, hệ thống không ghi nhận xuất kho và báo lỗi.

## Lịch Sử Nhập Xuất Kho

Admin xem tại menu `Lịch sử kho`.

Nguồn dữ liệu nằm ở `wp_uniform_inventory_movements`:

### Import nhập kho bằng template UMS

Trang `Sản phẩm & Tổng kho` có chức năng tải template `.xlsx` trống gồm `STT`, `Loại sản phẩm`, `Số lượng` và `Ghi chú`. Admin tự nhập các dòng hàng cần nhập kho; template không sinh trước danh sách sản phẩm. Size được đặt ở cuối tên, ví dụ `Quần CN Size L` hoặc `Giầy KPR O-010 Size 35`. Importer vẫn đọc được template 5 cột cũ có cột `Size` riêng. Hai cách viết `Giầy` và `Giày` được coi là tương đương khi đối chiếu và tổng hợp nhưng dữ liệu nguồn không bị tự ý đổi tên.

Khi đọc file, UMS ưu tiên đối chiếu nguyên tên `Loại sản phẩm` với cột `Loại` của master Mã SAP. Nếu file nhập theo tên chuẩn, hệ thống tách hậu tố `Size ...` và đối chiếu cặp `Loại đồng phục lên PR + Size`. Nhiều dòng master cùng quy về một `inventory_item_id` được xem là cùng một sản phẩm kho; chỉ trường hợp quy về nhiều `inventory_item_id` khác nhau mới bị báo lỗi ánh xạ.

Import nhập kho đối chiếu `Loại sản phẩm` với cột `Loại` của master Mã SAP; nếu file dùng tên chuẩn thì hệ thống cũng nhận `Loại đồng phục lên PR + Size`. Kết quả ánh xạ phải quy về đúng một `inventory_item_id` đã có, sau đó UMS chỉ cộng tồn và ghi lịch sử trong cùng transaction. Import kho không tự tạo danh mục, sản phẩm hoặc size mới; dữ liệu chưa có ánh xạ phải được bổ sung qua module Mã SAP đồng phục trước.

Luồng xử lý gồm `Tải template nhập kho` -> nhập số lượng -> `Đọc và xem trước` -> kiểm tra tồn trước/sau -> `Xác nhận nhập kho`. Việc cộng tồn và ghi lịch sử chạy trong một transaction; nếu một dòng lỗi, toàn bộ file được rollback. Hash file đã nhập thành công được lưu để ngăn import trùng.

Chức năng cần bảng `wp_uniform_inventory_import_batches` cùng hai cột `import_batch_id`, `source_row` trong `wp_uniform_inventory_movements`, đã được khai báo trong `ums.sql`. Plugin không tự tạo hoặc tự sửa bảng.

- `in`: nhập kho hoặc tăng tồn kho từ Admin.
- `out`: xuất kho chủ động từ Admin hoặc xuất kho sau khi phiếu được duyệt hoàn toàn.
- `adjust`: cập nhật thông tin sản phẩm/tồn kho nhưng không đổi số lượng.
- `request_out`: user gửi yêu cầu xuất kho, có liên kết `request_id`, người tạo và người nhận.

Trang lịch sử hiển thị thời gian, loại phát sinh, mã phiếu, sản phẩm, size, số lượng, tồn trước/sau, đơn giá, thành tiền, người thao tác, người nhận và ghi chú.

## Đồng Bộ Mật Khẩu Ngoài

Có thể cấu hình DB nguồn bằng hằng số trong `wp-config.php`:

```php
define( 'UMS_PASSWORD_SYNC_DB_HOST', '172.30.134.15' );
define( 'UMS_PASSWORD_SYNC_DB_USER', 'Tvnsoft' );
define( 'UMS_PASSWORD_SYNC_DB_PASSWORD', 'your-password' );
define( 'UMS_PASSWORD_SYNC_DB_NAME', 'tvnias' );
```

Hash lấy từ DB nguồn được ghi trực tiếp vào `wp_users.user_pass`, không hash lại. Nếu đồng bộ thất bại, hệ thống đặt mật khẩu về mặc định `12345678` bằng hàm hash của WordPress.

## Sơ Đồ Tổ Chức TVN

Admin quản lý tại menu `Sơ đồ tổ chức TVN`. Giao diện dùng jqxGrid phân trang phía server và đọc dữ liệu từ bảng nội bộ `wp_uniform_organization_employees`.

Nút `Đồng bộ từ Google Sheet` trên trang này mở Google Apps Script Web App bằng Popup Bridge và gửi dữ liệu Sheet `Danh sách CNV` về receiver `POST /wp-json/ums/v1/sync-organization`. Dữ liệu được upsert vào bảng nội bộ theo `Mã nhân viên`; cột `STT` chỉ dùng để hiển thị. Batch cuối gửi `finalize=true` để xóa các bản ghi không còn trong Sheet.

Sau khi lưu dữ liệu sơ đồ tổ chức, hệ thống tự tạo/cập nhật tài khoản WordPress theo `employee_no` cho nhân sự có email công ty `@toto...`. `user_login` là mã nhân viên, `user_email` lấy từ cột `Email`, tên hiển thị lấy từ `Họ và tên`, mật khẩu được đồng bộ từ server password hiện tại `172.30.134.15`; nếu đồng bộ password thất bại, hệ thống dùng mật khẩu mặc định `12345678`. Các nhân sự không có email công ty vẫn được lưu trong sơ đồ tổ chức nhưng không được tạo/cập nhật tài khoản đăng nhập.

Module này không còn kết nối database ngoài. Plugin không tự tạo bảng; cần import bảng `wp_uniform_organization_employees` từ `ums.sql` trước lần đồng bộ đầu tiên.

Với database đã có bảng tổ chức từ bản cũ, chạy thủ công:

```sql
ALTER TABLE `wp_uniform_organization_employees`
    ADD COLUMN `sheet_stt` INT DEFAULT NULL AFTER `source_id`,
    ADD COLUMN `cost_center` VARCHAR(100) DEFAULT NULL AFTER `position`,
    ADD COLUMN `date_joined` DATE DEFAULT NULL AFTER `cost_center`,
    ADD COLUMN `previous_position` VARCHAR(50) DEFAULT NULL AFTER `date_joined`,
    ADD UNIQUE KEY `idx_employee_no_unique` (`employee_no`(50)),
    ADD KEY `idx_sheet_stt` (`sheet_stt`),
    ADD KEY `idx_cost_center` (`cost_center`),
    ADD KEY `idx_date_joined` (`date_joined`);
```

## Đồng Bộ Sơ Đồ Tổ Chức Từ Google Sheet

Plugin cung cấp receiver `POST /wp-json/ums/v1/sync-organization`. Endpoint xác thực bằng header `X-Sync-Token`; token được lưu trong `wp_options` và hiển thị tại Admin menu `Đồng bộ Sheet`. Sheet nguồn duy nhất là `Danh sách CNV`, gồm các cột `STT`, `Mã nhân viên`, `Họ và tên`, `Phòng`, `Nhóm`, `Mã cost center`, `Ngày vào`, `Vị trí`, `Vị trí trước TT`, `Email`, `Ngày ký hợp đồng đầu tiên`.

Do Google Workspace có SSO và WordPress chạy nội bộ, hệ thống dùng mô hình Popup Bridge thay vì GAS trigger server-to-server. Admin bấm `Đồng bộ từ Google Sheet` trong trang `Sơ đồ tổ chức TVN`, plugin mở Google Apps Script Web App bằng `window.open()`, popup đọc Sheet bằng phiên SSO trình duyệt rồi `fetch()` JSON về endpoint nội bộ của WordPress. Nếu trình duyệt chặn POST trực tiếp từ popup, popup chuyển payload về trang Admin bằng `postMessage` để Admin POST cùng-origin vào UMS.

Google Apps Script mẫu gồm `ums-organization-sync.gs` và `UmsTvnOrgIndex.html`, hướng dẫn cài đặt nằm tại `integrations/google-apps-script/` của plugin Connector.

### Auto Sync 1 Lần/Ngày Không Cần Đăng Nhập WP Admin

Vì Google Apps Script chạy trên server Google không thể truy cập IP nội bộ `172.30.134.76`, lịch tự động cần chạy trên một máy nội bộ. Máy này cần mở được UMS và dùng Chrome profile đã đăng nhập SSO Google Workspace. WordPress Admin không cần duy trì phiên đăng nhập.

Plugin cung cấp `Auto Bridge URL` tại Admin menu `Đồng bộ Sheet`. URL có dạng:

```text
http://172.30.134.76/UMS/?ums_auto_sync_bridge=1&token=...
```

Khi URL này được mở, bridge kiểm tra token riêng, tự mở popup Apps Script, nhận dữ liệu qua `postMessage` và POST về WordPress bằng `X-Sync-Token`.

File PowerShell mẫu:

```text
tools/ums-organization-auto-sync.ps1
```

Thiết lập Windows Task Scheduler:

```text
Program/script:
powershell.exe

Arguments:
-ExecutionPolicy Bypass -File "C:\xampp\htdocs\UMS\wp-content\plugins\UMS\tools\ums-organization-auto-sync.ps1"

Trigger:
Daily, 1 time per day
```

Trước khi đặt lịch, copy `Auto Bridge URL` từ UMS Admin > `Đồng bộ Sheet` và dán vào biến `$SyncUrl` trong file PowerShell mẫu. Nên cho phép popup cho site `http://172.30.134.76` trong Chrome, hoặc dùng script mẫu vì script đã mở Chrome với `--disable-popup-blocking`.

## Cấu Trúc Thư Mục Chính

```text
UMS/
|-- admin/
|   |-- class-ums-admin.php
|   |-- css/
|   |-- js/
|   `-- partials/
|       |-- view-annual-allowance-list.php
|       |-- view-approval-flow-list.php
|       |-- view-contract-type-list.php
|       |-- view-department-list.php
|       |-- view-factory-location-list.php
|       |-- view-inventory-list.php
|       |-- view-inventory-movement-list.php
|       |-- view-organization-list.php
|       |-- view-position-list.php
|       |-- view-product-category-list.php
|       `-- view-user-list.php
|-- assets/
|-- includes/
|   |-- class-ums-helper.php
|   |-- class-ums-password-sync.php
|   `-- db/
|       |-- class-ums-db-annual-allowance.php
|       |-- class-ums-db-approval-flow.php
|       |-- class-ums-db-base.php
|       |-- class-ums-db-contract-type.php
|       |-- class-ums-db-department.php
|       |-- class-ums-db-factory-location.php
|       |-- class-ums-db-inventory.php
|       |-- class-ums-db-inventory-movement.php
|       |-- class-ums-db-organization.php
|       |-- class-ums-db-position.php
|       |-- class-ums-db-product-category.php
|       |-- class-ums-db-request.php
|       `-- class-ums-db-user.php
|-- user/
|   |-- class-ums-user.php
|   |-- css/
|   |-- js/
|   `-- partials/
|       |-- components/
|       |-- layout/
|       `-- pages/
|-- tvn-uniform-management.php
|-- ums.sql
`-- Readme.md
```

## Tính Số Lượng Và Xuất PR

Admin sử dụng menu `Tính số lượng PR`. File đầu vào là workbook `6. Template số lượng đặt dự phòng.xlsx`, sheet `Sheet1`, gồm hai cột `Loại đồng phục dự phòng` và `Số lượng`.

Dữ liệu dự phòng chỉ tồn tại trong file upload và request hiện tại; hệ thống không ghi file, không dùng transient và không tạo thêm bảng database. Khi Admin thay đổi file hoặc điều kiện, kết quả cũ bị vô hiệu hóa và phải tính lại trước khi xuất.

Công thức áp dụng theo từng dòng master mã SAP và size:

```text
SL PR = max(0, SL cấp phát đã chốt của kỳ + SL dự phòng - Tồn kho hiện tại)
```

Tên loại trong file dự phòng phải khớp duy nhất với cột `item_name` của master mã SAP. Master tiếp tục dùng `inventory_item_id` để lấy size, tồn kho và đơn giá từ UMS. Dòng cần lên PR nhưng chưa có đơn giá được cảnh báo trên màn hình và không được xuất file.

Kết quả được hiển thị bằng jqxGrid. Nút `Xuất file PR` tính lại trực tiếp từ file đang chọn rồi ghi vào workbook mẫu tại `assets/templates/ums-pr-template.xlsx`; sheet mapping của mẫu được giữ nguyên. Nhu cầu cấp phát được đọc từ snapshot đang hoạt động đúng năm và kỳ T4/T9. Nếu chưa chốt kết quả cho kỳ đã chọn, hệ thống không cho tính hoặc xuất PR.

## Quản Lý CNV Nghỉ Việc

Sau một lần đồng bộ đầy đủ, CNV không còn trên Google Sheet được chuyển sang trạng thái `left` thay vì bị xóa. Hệ thống tạo hồ sơ thu hồi từ các movement xuất kho thực tế (`movement_type = out`); dữ liệu tính SL cấp phát hoặc PR không được coi là đã cấp.

Thứ tự phân loại: mã bắt đầu bằng `M1`/`F1` là lao động cho thuê lại; các mã khác có ngày ký hợp đồng đầu tiên là HĐLĐ chính thức; còn lại là tập nghề/thử việc. Hàng thu hồi đủ điều kiện tái sử dụng được cộng kho bằng movement `return_in`.

Với database đã tồn tại, chạy `update-employee-exit.sql` trước lần đồng bộ Google Sheet tiếp theo.
